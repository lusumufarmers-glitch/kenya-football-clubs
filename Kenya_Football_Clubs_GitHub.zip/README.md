# Kenya Football Clubs 🇰🇪⚽

A mobile-friendly Kenyan football club management game.

## Run
Open `index.html` in a browser.

## GitHub Pages
1. Create a GitHub repository named `kenya-football-clubs`.
2. Upload `index.html` and `README.md`.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main`, and save.
5. GitHub will provide the public game website.

## Current clubs
Gor Mahia, AFC Leopards, Tusker FC, KCB FC, Bandari FC, Kariobangi Sharks, Police FC, Ulinzi Stars, Shabana FC and Kenya Police Bullets.

## Next upgrades
Online accounts, saving progress, league seasons, player transfers, stadiums, kits, match animations, sound, and Android APK.
